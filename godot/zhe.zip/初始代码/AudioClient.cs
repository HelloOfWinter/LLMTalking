using Godot;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using Pv; // PvRecorder 音频录制库命名空间

// 音频处理接口定义
public interface IAudioProcessor
{
    byte[] ProcessAudio(short[] pcmData, int sampleRate);
}

public interface IAudioSender
{
    Task SendAudioInChunks(byte[] audioData);
}

public interface IAudioPlayer
{
    void PlayAudio(byte[] audioData, int sampleRate);
}

public interface IUIHandler
{
    void UpdateStatus(string text);
    void SetButtonsEnabled(bool recordEnabled, bool stopEnabled);
}

/// <summary>
/// 音频客户端核心类（Godot 4.6 C#适配版）
/// 功能：录音（PvRecorder）→ 分片发送 → 接收服务器音频回复 → 按句子顺序播放 + 历史对话管理
/// </summary>
public partial class AudioClient : Node, IAudioProcessor, IAudioSender, IAudioPlayer, IUIHandler
{
    // ==================== 常量配置 ====================
    private const string ServerUrl = "ws://localhost:8765/ws";
    private const int TargetSampleRate = 16000;
    private const int TargetChannels = 1;
    private const int ChunkSize = 32 * 1024;
    private const float ChunkDelay = 0.05f;
    private const int PvRecorderFrameLength = 512;

    // ==================== 核心成员变量 ====================
    private WebSocketPeer _wsClient;
    private bool _wsConnected;
    private bool _isRecording;

    private PvRecorder _pvRecorder;
    private List<short> _recordedFrames;
    private System.Threading.Thread _recordingThread;
    private volatile bool _shouldStopRecording;

    private AudioStreamPlayer _audioPlayer;

    private class SentenceBuffer
    {
        public int TotalChunks;
        public Dictionary<int, string> Chunks = new();
        public string Text;
        public int SampleRate;
    }
    private Dictionary<int, SentenceBuffer> _sentenceBuffers = new();
    private Queue<int> _readySentenceIndices = new();
    private int _nextPlayIndex = 0;
    private bool _isPlaying = false;

    private Button _recordButton;
    private Button _stopButton;
    private Label _statusLabel;

    // ==================== 新增：历史对话管理相关变量 ====================
    private List<Dictionary<string, string>> _conversationHistories = new List<Dictionary<string, string>>();
    private string _currentConversationId = null;
    private bool _isHistoryLoading = false;

    // 历史对话管理UI元素（Godot 4适配，使用ItemList替代ListView）
    private Control _historyPanel;
    private Label _historyTitle;
    private Button _loadHistoryButton;
    private Button _saveHistoryButton;
    private Button _deleteHistoryButton;
    private ItemList _historyItemList; // 替换ListView为ItemList
    private Button _historyButton; // 显示/隐藏历史面板的按钮

    // ==================== 生命周期与初始化 ====================
    public override void _Ready()
    {
        GD.Print("[启动] 音频客户端初始化中...");
        FindAndAssignUiNodes();
        UpdateStatus("正在初始化...");
        InitPvRecorder();
        InitAudioPlayer();
        ConnectToServer();
        BindUiSignals();
        InitHistoryPanel(); // 新增：初始化历史对话面板
    }

    private void FindAndAssignUiNodes()
    {
        // Godot 4 GetNodeOrNull<T> 泛型用法适配
        _recordButton = GetNodeOrNull<Button>("RecordButton");
        _stopButton = GetNodeOrNull<Button>("StopButton");
        _statusLabel = GetNodeOrNull<Label>("StatusLabel");
        _historyButton = GetNodeOrNull<Button>("HistoryButton");

        // 嵌套节点查找适配
        if (_recordButton == null || _stopButton == null || _statusLabel == null || _historyButton == null)
        {
            var control = GetNodeOrNull<Control>("Control");
            if (control != null)
            {
                _recordButton ??= control.GetNodeOrNull<Button>("RecordButton");
                _stopButton ??= control.GetNodeOrNull<Button>("StopButton");
                _statusLabel ??= control.GetNodeOrNull<Label>("StatusLabel");
                _historyButton ??= control.GetNodeOrNull<Button>("HistoryButton");
            }
        }
    }

    private void InitPvRecorder()
    {
        GD.Print("[音频] 初始化 PvRecorder...");
        try
        {
            _pvRecorder = PvRecorder.Create(deviceIndex: -1, frameLength: PvRecorderFrameLength);
            GD.Print($"[音频] PvRecorder 初始化成功");
            GD.Print($"  - 采样率: {_pvRecorder.SampleRate} Hz");
            GD.Print($"  - 帧长度: {_pvRecorder.FrameLength} samples");
            GD.Print($"  - 所选设备: {_pvRecorder.SelectedDevice}");
            _recordedFrames = new List<short>();
        }
        catch (PvRecorderException e)
        {
            GD.PrintErr($"[错误] PvRecorder 初始化失败: {e.Message}");
            UpdateStatus("错误：麦克风初始化失败");
        }
    }

    private void InitAudioPlayer()
    {
        _audioPlayer = new AudioStreamPlayer();
        _audioPlayer.Name = "AudioPlayer";
        AddChild(_audioPlayer);
    }

    private void BindUiSignals()
    {
        if (_recordButton != null)
        {
            _recordButton.Pressed += OnRecordButtonPressed;
            _recordButton.Disabled = true;
        }
        if (_stopButton != null)
        {
            _stopButton.Pressed += OnStopButtonPressed;
            _stopButton.Disabled = true;
        }
        if (_historyButton != null)
        {
            _historyButton.Pressed += OnHistoryButtonPressed;
        }
    }

    private void ConnectToServer()
    {
        GD.Print($"[连接] 尝试连接: {ServerUrl}");
        UpdateStatus("正在连接服务器...");
        _wsClient = new WebSocketPeer();
        Error err = _wsClient.ConnectToUrl(ServerUrl);
        if (err != Error.Ok)
        {
            GD.Print($"[错误] 连接失败: {err}");
            UpdateStatus("连接失败");
            return;
        }
    }

    public override void _Process(double delta)
    {
        if (_wsClient == null) return;

        _wsClient.Poll();

        var currentState = _wsClient.GetReadyState();
        if (currentState == WebSocketPeer.State.Open && !_wsConnected)
            OnConnected();
        else if (currentState != WebSocketPeer.State.Open && _wsConnected)
            OnDisconnected();

        while (_wsClient.GetAvailablePacketCount() > 0)
        {
            byte[] packet = _wsClient.GetPacket();
            string message = Encoding.UTF8.GetString(packet);
            if (!string.IsNullOrEmpty(message))
                HandleServerMessage(message);
        }
    }

    private void OnConnected()
    {
        _wsConnected = true;
        GD.Print("[连接] 已成功连接到服务器");
        UpdateStatus("已连接 - 点击录音开始");
        _wsClient.InboundBufferSize = 5 * 1024 * 1024;
        if (_recordButton != null) _recordButton.Disabled = false;

        // 连接成功后加载历史对话列表
        LoadConversationHistoryList();
    }

    private void OnDisconnected()
    {
        _wsConnected = false;
        GD.Print("[连接] 与服务器断开连接");
        UpdateStatus("已断开连接");
        if (_recordButton != null) _recordButton.Disabled = true;
        if (_stopButton != null) _stopButton.Disabled = true;
        if (_isRecording) StopRecording();
    }

    // ==================== 录音逻辑（PvRecorder） ====================
    private void StartRecording()
    {
        if (!_wsConnected || _isRecording || _pvRecorder == null) return;

        // 重置播放状态，为新对话做准备
        ResetPlaybackState();

        try
        {
            GD.Print("[录音] 开始录制...");
            UpdateStatus("🔴 正在录音...");
            _isRecording = true;
            _shouldStopRecording = false;
            _recordedFrames.Clear();

            _pvRecorder.Start();
            GD.Print($"[录音] PvRecorder 已启动，采样率: {_pvRecorder.SampleRate} Hz");

            _recordingThread = new System.Threading.Thread(RecordingThreadFunc);
            _recordingThread.Start();

            if (_recordButton != null) _recordButton.Disabled = true;
            if (_stopButton != null) _stopButton.Disabled = false;
        }
        catch (PvRecorderException e)
        {
            GD.PrintErr($"[错误] 启动录音失败: {e.Message}");
            UpdateStatus("错误：启动录音失败");
            _isRecording = false;
        }
    }

    private void RecordingThreadFunc()
    {
        GD.Print("[录音线程] 开始采集音频");
        try
        {
            while (!_shouldStopRecording && _pvRecorder.IsRecording)
            {
                short[] frame = _pvRecorder.Read();
                lock (_recordedFrames)
                {
                    _recordedFrames.AddRange(frame);
                }
            }
        }
        catch (PvRecorderException e)
        {
            if (!_shouldStopRecording)
            {
                GD.PrintErr($"[错误] 录音线程异常: {e.Message}");
            }
        }
        finally
        {
            GD.Print("[录音线程] 结束采集");
        }
    }

    private void StopRecording()
    {
        if (!_isRecording) return;

        GD.Print("[录音] 停止录制");
        UpdateStatus("正在处理音频...");

        _shouldStopRecording = true;

        if (_recordingThread != null && _recordingThread.IsAlive)
        {
            _recordingThread.Join(1000);
        }

        try
        {
            if (_pvRecorder.IsRecording)
            {
                _pvRecorder.Stop();
            }
        }
        catch (PvRecorderException e)
        {
            GD.PrintErr($"[警告] 停止 PvRecorder 时出错: {e.Message}");
        }

        _isRecording = false;
        if (_recordButton != null) _recordButton.Disabled = false;
        if (_stopButton != null) _stopButton.Disabled = true;

        ProcessAndSendRecordedAudio();
    }

    private void ProcessAndSendRecordedAudio()
    {
        short[] recordedData;
        lock (_recordedFrames)
        {
            if (_recordedFrames.Count == 0)
            {
                GD.Print("[错误] 未录到任何音频数据");
                UpdateStatus("错误：未录到声音");
                return;
            }
            recordedData = _recordedFrames.ToArray();
        }

        GD.Print("-------------------");
        GD.Print("[调试] 录音信息:");
        GD.Print($"  - 总样本数: {recordedData.Length}");
        GD.Print($"  - 时长: {recordedData.Length / (float)_pvRecorder.SampleRate:F2} 秒");
        GD.Print($"  - 原始采样率: {_pvRecorder.SampleRate} Hz");
        GD.Print("-------------------");

        byte[] pcmBytes = new byte[recordedData.Length * 2];
        Buffer.BlockCopy(recordedData, 0, pcmBytes, 0, pcmBytes.Length);

        byte[] finalData = pcmBytes;

        // 保存调试WAV文件
        string desktop = System.Environment.GetFolderPath(System.Environment.SpecialFolder.Desktop);
        string debugPath = System.IO.Path.Combine(desktop, "pvrecorder_debug.wav");
        if (SaveWavFile(debugPath, finalData, _pvRecorder.SampleRate, 1, 16))
            GD.Print($"[调试] 录音已保存到桌面: {debugPath}");
        else
            GD.Print("[错误] 调试文件保存失败");

        if (_wsClient.GetReadyState() != WebSocketPeer.State.Open)
        {
            UpdateStatus("错误：连接已断开");
            return;
        }

        GD.Print($"[发送] 最终数据大小: {finalData.Length} 字节");
        _ = SendAudioInChunks(finalData);
    }

    private bool SaveWavFile(string path, byte[] pcmData, int sampleRate, int channels, int bitsPerSample)
    {
        try
        {
            using var fs = new System.IO.FileStream(path, System.IO.FileMode.Create);
            using var writer = new System.IO.BinaryWriter(fs);
            writer.Write(Encoding.UTF8.GetBytes("RIFF"));
            writer.Write(36 + pcmData.Length);
            writer.Write(Encoding.UTF8.GetBytes("WAVE"));
            writer.Write(Encoding.UTF8.GetBytes("fmt "));
            writer.Write(16);
            writer.Write((short)1);
            writer.Write((short)channels);
            writer.Write(sampleRate);
            int byteRate = sampleRate * channels * bitsPerSample / 8;
            writer.Write(byteRate);
            short blockAlign = (short)(channels * bitsPerSample / 8);
            writer.Write(blockAlign);
            writer.Write((short)bitsPerSample);
            writer.Write(Encoding.UTF8.GetBytes("data"));
            writer.Write(pcmData.Length);
            writer.Write(pcmData);
            return true;
        }
        catch (Exception e)
        {
            GD.PrintErr("保存WAV文件失败: " + e.Message);
            return false;
        }
    }

    private async Task SendAudioInChunks(byte[] audioData)
    {
        int totalSize = audioData.Length;
        int numChunks = (int)Math.Ceiling(totalSize / (double)ChunkSize);
        GD.Print($"[分片] 准备发送 {numChunks} 片");
        UpdateStatus($"正在发送数据 (0/{numChunks})");

        for (int i = 0; i < numChunks; i++)
        {
            int start = i * ChunkSize;
            int end = Math.Min(start + ChunkSize, totalSize);
            int chunkLength = end - start;

            byte[] chunkData = new byte[chunkLength];
            Array.Copy(audioData, start, chunkData, 0, chunkLength);

            string chunkBase64 = Convert.ToBase64String(chunkData);

            var chunkMsg = new Godot.Collections.Dictionary
            {
                ["type"] = "audio_chunk",
                ["seq"] = i,
                ["total"] = numChunks,
                ["data"] = chunkBase64,
                ["sample_rate"] = TargetSampleRate,
                ["channels"] = TargetChannels,
                ["conversation_id"] = _currentConversationId
            };
            string jsonStr = Json.Stringify(chunkMsg);

            Error err = _wsClient.SendText(jsonStr);
            if (err != Error.Ok)
            {
                GD.Print($"[错误] 分片 {i} 发送失败");
                UpdateStatus("发送失败");
                return;
            }

            UpdateStatus($"正在发送数据 ({i + 1}/{numChunks})");

            if (ChunkDelay > 0)
                await ToSignal(GetTree().CreateTimer(ChunkDelay), Timer.SignalName.Timeout);
        }

        GD.Print("[发送] 音频数据发送完成");
        UpdateStatus("等待AI回复...");
    }

    // ==================== 服务器消息处理（Godot 4 JSON解析适配） ====================
    private void HandleServerMessage(string message)
    {
        // 使用Godot 4推荐的Json.ParseString解析JSON
        var json = Json.ParseString(message);
        if (json.VariantType != Variant.Type.Dictionary) return;
        var data = json.AsGodotDictionary();

        if (!data.ContainsKey("type")) return;
        string type = data["type"].AsString().ToLower();

        switch (type)
        {
            case "sentence_start":
                HandleSentenceStart(data);
                break;
            case "audio_chunk":
                HandleAudioChunk(data);
                break;
            case "stream_end":
                HandleStreamEnd();
                break;
            case "ping":
                var pongMsg = new Godot.Collections.Dictionary { ["type"] = "pong" };
                _wsClient.SendText(Json.Stringify(pongMsg));
                break;
            case "history_load":
                HandleHistoryLoad(data);
                break;
            case "history_saved":
                HandleHistorySaved(data);
                break;
            case "history_deleted":
                HandleHistoryDeleted(data);
                break;
            case "history_list":
                HandleHistoryList(data);
                break;
            case "conversation_created":
                _currentConversationId = data["conversation_id"].AsString();
                GD.Print($"[对话] 新对话创建，ID: {_currentConversationId}");
                break;
        }
    }

    private void HandleSentenceStart(Godot.Collections.Dictionary data)
    {
        int idx = data.GetValueOrDefault("idx", -1).AsInt32();
        if (idx < 0) return;

        if (idx == 0 && _nextPlayIndex != 0)
        {
            GD.Print("[播放] 检测到新对话开始，重置播放状态");
            ResetPlaybackState();
        }

        string text = data.GetValueOrDefault("text", "").AsString();
        int totalChunks = data.GetValueOrDefault("total_chunks", 0).AsInt32();
        int sampleRate = data.GetValueOrDefault("sample_rate", TargetSampleRate).AsInt32();

        var buffer = new SentenceBuffer
        {
            TotalChunks = totalChunks,
            Text = text,
            SampleRate = sampleRate
        };
        _sentenceBuffers[idx] = buffer;

        GD.Print($"[接收] 开始句子 {idx}: {text}");
        UpdateStatus($"收到句子 {idx}");
    }

    private void HandleAudioChunk(Godot.Collections.Dictionary data)
    {
        int sentenceIdx = data.GetValueOrDefault("sentence_idx", -1).AsInt32();
        int seq = data.GetValueOrDefault("seq", -1).AsInt32();
        if (sentenceIdx < 0 || seq < 0) return;

        string chunkData = data.GetValueOrDefault("data", "").AsString();

        if (_sentenceBuffers.TryGetValue(sentenceIdx, out var buffer))
        {
            buffer.Chunks[seq] = chunkData;

            if (buffer.Chunks.Count == buffer.TotalChunks)
            {
                GD.Print($"[接收] 句子 {sentenceIdx} 所有分片收齐");
                _readySentenceIndices.Enqueue(sentenceIdx);
                CallDeferred(nameof(TryPlayNextSentence));
            }
        }
    }

    private void HandleStreamEnd()
    {
        GD.Print("[接收] 流式传输结束");
        UpdateStatus("回复接收完毕");
    }

    private void TryPlayNextSentence()
    {
        if (_isPlaying) return;

        while (_readySentenceIndices.Count > 0 && _readySentenceIndices.Peek() == _nextPlayIndex)
        {
            int idx = _readySentenceIndices.Dequeue();
            if (_sentenceBuffers.TryGetValue(idx, out var buffer))
            {
                _ = PlaySentenceAsync(idx, buffer);
                _nextPlayIndex = idx + 1;
                return;
            }
        }
    }

    private async Task PlaySentenceAsync(int idx, SentenceBuffer buffer)
    {
        _isPlaying = true;

        try
        {
            var fullBase64 = new StringBuilder();
            for (int i = 0; i < buffer.TotalChunks; i++)
            {
                fullBase64.Append(buffer.Chunks[i]);
            }

            byte[] audioData = Convert.FromBase64String(fullBase64.ToString());
            GD.Print($"[播放] 句子 {idx}: {buffer.Text}");
            UpdateStatus($"播放: {buffer.Text}");

            var audioStream = new AudioStreamWav();
            audioStream.Format = AudioStreamWav.FormatEnum.Format16Bits;
            audioStream.MixRate = buffer.SampleRate;
            audioStream.Stereo = false;
            audioStream.Data = audioData;

            if (_audioPlayer.Playing) _audioPlayer.Stop();
            _audioPlayer.Stream = audioStream;
            _audioPlayer.Play();

            await ToSignal(_audioPlayer, AudioStreamPlayer.SignalName.Finished);
        }
        catch (Exception e)
        {
            GD.PrintErr($"[错误] 播放句子 {idx} 失败: {e.Message}");
            UpdateStatus($"播放失败: {buffer.Text}");
        }
        finally
        {
            _isPlaying = false;
            _sentenceBuffers.Remove(idx);
            CallDeferred(nameof(TryPlayNextSentence));
        }
    }

    // ==================== 重置播放状态 ====================
    private void ResetPlaybackState()
    {
        _sentenceBuffers.Clear();
        _readySentenceIndices.Clear();
        _nextPlayIndex = 0;
        if (_audioPlayer.Playing)
        {
            _audioPlayer.Stop();
        }
        _isPlaying = false;
        GD.Print("[播放] 播放状态已重置，等待新对话...");
    }

    // ==================== UI与接口实现 ====================
    private void UpdateStatus(string text)
    {
        GD.Print($"[状态] {text}");
        if (_statusLabel != null)
            _statusLabel.Text = text;
    }

    private void OnRecordButtonPressed() => StartRecording();
    private void OnStopButtonPressed() => StopRecording();

    byte[] IAudioProcessor.ProcessAudio(short[] pcmData, int sampleRate)
    {
        byte[] bytes = new byte[pcmData.Length * 2];
        Buffer.BlockCopy(pcmData, 0, bytes, 0, bytes.Length);
        return bytes;
    }

    async Task IAudioSender.SendAudioInChunks(byte[] audioData) => await SendAudioInChunks(audioData);
    void IAudioPlayer.PlayAudio(byte[] audioData, int sampleRate) => _ = PlayAudioAsync(audioData, sampleRate);
    void IUIHandler.UpdateStatus(string text) => UpdateStatus(text);
    void IUIHandler.SetButtonsEnabled(bool recordEnabled, bool stopEnabled)
    {
        if (_recordButton != null) _recordButton.Disabled = !recordEnabled;
        if (_stopButton != null) _stopButton.Disabled = !stopEnabled;
    }

    private async Task PlayAudioAsync(byte[] audioData, int sampleRate)
    {
        try
        {
            var audioStream = new AudioStreamWav();
            audioStream.Format = AudioStreamWav.FormatEnum.Format16Bits;
            audioStream.MixRate = sampleRate;
            audioStream.Stereo = false;
            audioStream.Data = audioData;

            if (_audioPlayer.Playing) _audioPlayer.Stop();
            _audioPlayer.Stream = audioStream;
            _audioPlayer.Play();

            await ToSignal(_audioPlayer, AudioStreamPlayer.SignalName.Finished);
            UpdateStatus("就绪 - 点击录音开始");
        }
        catch (Exception e)
        {
            GD.PrintErr("播放音频出错: " + e.Message);
            UpdateStatus("播放失败");
        }
    }

    // ==================== 历史对话管理（Godot 4 UI核心适配） ====================
    private void InitHistoryPanel()
    {
        // 创建历史对话面板
        _historyPanel = new Control();
        _historyPanel.Size = new Vector2(300, 400);
        _historyPanel.Position = new Vector2(10, 10);
        _historyPanel.Visible = false;
        _historyPanel.Modulate = new Color(1, 1, 1, 0.95f);

        // 使用BgColor替代BackgroundColor
        var panelStyle = new StyleBoxFlat();
        panelStyle.BgColor = new Color(0.1f, 0.1f, 0.1f);
        _historyPanel.AddThemeStyleboxOverride("panel", panelStyle);

        // 标题
        _historyTitle = new Label();
        _historyTitle.Text = "历史对话";
        _historyTitle.Position = new Vector2(10, 10);
        _historyTitle.AddThemeFontSizeOverride("font_size", 16);
        _historyPanel.AddChild(_historyTitle);

        // 历史列表（使用ItemList替代ListView）
        _historyItemList = new ItemList();
        _historyItemList.Position = new Vector2(10, 40);
        _historyItemList.Size = new Vector2(280, 280);

        var listStyle = new StyleBoxFlat();
        listStyle.BgColor = new Color(0.2f, 0.2f, 0.2f);
        _historyItemList.AddThemeStyleboxOverride("panel", listStyle);
        _historyPanel.AddChild(_historyItemList);

        // 加载按钮
        _loadHistoryButton = new Button();
        _loadHistoryButton.Text = "加载";
        _loadHistoryButton.Position = new Vector2(10, 330);
        _loadHistoryButton.Size = new Vector2(80, 30);
        _loadHistoryButton.Pressed += OnLoadHistoryPressed;
        _historyPanel.AddChild(_loadHistoryButton);

        // 保存按钮
        _saveHistoryButton = new Button();
        _saveHistoryButton.Text = "保存";
        _saveHistoryButton.Position = new Vector2(100, 330);
        _saveHistoryButton.Size = new Vector2(80, 30);
        _saveHistoryButton.Pressed += OnSaveHistoryPressed;
        _historyPanel.AddChild(_saveHistoryButton);

        // 删除按钮
        _deleteHistoryButton = new Button();
        _deleteHistoryButton.Text = "删除";
        _deleteHistoryButton.Position = new Vector2(190, 330);
        _deleteHistoryButton.Size = new Vector2(80, 30);
        _deleteHistoryButton.Pressed += OnDeleteHistoryPressed;
        _historyPanel.AddChild(_deleteHistoryButton);

        AddChild(_historyPanel);
    }

    private void LoadConversationHistoryList()
    {
        if (_wsClient == null || !_wsConnected) return;

        _isHistoryLoading = true;
        UpdateStatus("正在加载历史对话...");

        var historyRequest = new Godot.Collections.Dictionary
        {
            ["type"] = "history_request",
            ["action"] = "list"
        };

        _wsClient.SendText(Json.Stringify(historyRequest));
    }

    // 修复：数组使用Length属性判断长度
    private void OnLoadHistoryPressed()
    {
        int[] selectedItems = _historyItemList.GetSelectedItems();
        if (_isHistoryLoading || selectedItems.Length == 0) return;

        int selectedIndex = selectedItems[0];
        if (selectedIndex < 0 || selectedIndex >= _conversationHistories.Count) return;

        string conversationId = _conversationHistories[selectedIndex]["conversation_id"];
        LoadConversationHistory(conversationId);
    }

    private void OnSaveHistoryPressed()
    {
        if (_currentConversationId == null)
        {
            UpdateStatus("错误：无当前对话可保存");
            return;
        }

        string title = "对话 " + DateTime.Now.ToString("yyyy-MM-dd HH:mm");

        var saveRequest = new Godot.Collections.Dictionary
        {
            ["type"] = "history_request",
            ["action"] = "save",
            ["conversation_id"] = _currentConversationId,
            ["title"] = title
        };

        _wsClient.SendText(Json.Stringify(saveRequest));
    }

    // 修复：数组使用Length属性判断长度
    private void OnDeleteHistoryPressed()
    {
        int[] selectedItems = _historyItemList.GetSelectedItems();
        if (_isHistoryLoading || selectedItems.Length == 0) return;

        int selectedIndex = selectedItems[0];
        if (selectedIndex < 0 || selectedIndex >= _conversationHistories.Count) return;

        string conversationId = _conversationHistories[selectedIndex]["conversation_id"];

        var deleteRequest = new Godot.Collections.Dictionary
        {
            ["type"] = "history_request",
            ["action"] = "delete",
            ["conversation_id"] = conversationId
        };

        _wsClient.SendText(Json.Stringify(deleteRequest));
    }

    private void LoadConversationHistory(string conversationId)
    {
        _isHistoryLoading = true;
        UpdateStatus("正在加载对话...");

        var loadRequest = new Godot.Collections.Dictionary
        {
            ["type"] = "history_request",
            ["action"] = "load",
            ["conversation_id"] = conversationId
        };

        _wsClient.SendText(Json.Stringify(loadRequest));
    }

    private void HandleHistoryLoad(Godot.Collections.Dictionary data)
    {
        _isHistoryLoading = false;
        UpdateStatus("对话加载完成");

        var history = data["history"].AsGodotDictionary();
        var messages = history["messages"].AsGodotArray();

        // 清空当前对话状态
        ResetPlaybackState();
        _currentConversationId = data["conversation_id"].AsString();

        // 显示对话历史
        foreach (var message in messages)
        {
            var msg = message.AsGodotDictionary();
            string role = msg["role"].AsString();
            string content = msg["content"].AsString();

            if (role == "user")
            {
                UpdateStatus($"用户: {content}");
            }
            else if (role == "assistant")
            {
                UpdateStatus($"AI: {content}");
            }
        }
    }

    private void HandleHistorySaved(Godot.Collections.Dictionary data)
    {
        _isHistoryLoading = false;
        UpdateStatus($"对话已保存: {data["title"].AsString()}");
        LoadConversationHistoryList();
    }

    private void HandleHistoryDeleted(Godot.Collections.Dictionary data)
    {
        _isHistoryLoading = false;
        UpdateStatus($"对话已删除: {data["conversation_id"].AsString()}");
        LoadConversationHistoryList();
    }

    // 使用ItemList的Clear方法清空列表
    private void HandleHistoryList(Godot.Collections.Dictionary data)
    {
        _isHistoryLoading = false;

        _conversationHistories.Clear();
        _historyItemList.Clear(); // 清空ItemList

        var histories = data["histories"].AsGodotArray();
        foreach (var history in histories)
        {
            var hist = history.AsGodotDictionary();
            string id = hist["id"].AsString();
            string title = hist["title"].AsString();
            string timestamp = hist["timestamp"].AsString();

            _conversationHistories.Add(new Dictionary<string, string>
            {
                ["conversation_id"] = id,
                ["title"] = title,
                ["timestamp"] = timestamp
            });

            _historyItemList.AddItem($"{title} ({timestamp})");
        }

        if (_conversationHistories.Count == 0)
        {
            _historyItemList.AddItem("暂无历史对话");
        }
    }

    private void OnHistoryButtonPressed()
    {
        _historyPanel.Visible = !_historyPanel.Visible;
    }

    // ==================== 资源释放（修复Dispose隐藏成员问题） ====================
    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            _shouldStopRecording = true;
            if (_recordingThread != null && _recordingThread.IsAlive)
                _recordingThread.Join(1000);

            _pvRecorder?.Dispose();
            // 直接使用ushort值1000，替代WebSocketPeer.CloseCode
            _wsClient?.Close(1000, "Exit");
        }
        base.Dispose(disposing);
    }
}